# Verificación de IMPORTADORA

## Tienda móvil, consultas fijas y campaña por referencia — 6 de octubre de 2026

- **80 pruebas aprobadas** con Python 3.12. Se incorporaron regresiones del filtro exacto de teléfono, enlace publicitario por referencia, mínimo mayorista y respuestas fijas basadas en disponibilidad. Las pruebas de inventario y ventas continúan usando bases temporales.
- Chromium a 320, 390, 768 y 1440 píxeles: catálogo y asistente sin desbordamiento horizontal, panel de preguntas dentro de la pantalla, respuestas de tienda en línea, mínimo combinado y envíos verificadas. No equivale a una prueba en cada modelo de celular físico.
- Pedido público de una o dos unidades bloqueado; desde tres habilitado. Las solicitudes no descuentan stock. La tarifa económica se confirma según el total; el envío personalizado a domicilio se informa como $5, sin añadirlo silenciosamente al subtotal de productos.
- Contenedor Docker de prueba: app funcional, salud HTTP y actualización con `scripts/actualizar_oracle.sh` verificados. El stock A06-01 se redujo a nueve antes de actualizar, y permaneció en nueve tras el reinicio. No se conectó a PostgreSQL de Oracle ni se modificó la tienda publicada.
- La construcción normal en este entorno de pruebas no resolvió DNS desde el constructor Docker, incluso con su red de host. Se validó la imagen usando un Dockerfile temporal con instalación sin red desde wheels descargados con verificación TLS normal. `deploy/Dockerfile` conserva la instalación normal para el servidor. No se desactivó TLS ni se cambiaron dependencias para ocultar el fallo de red.
- Entrega publicitaria corregida: 48 PNG de las 24 referencias, en feed 1080×1350 e historias 1080×1920; 36 Samsung y 12 iPhone. Las tres referencias 17PM/18PM se incluyen como borradores con etiqueta del proveedor y ajuste físico pendiente visible. Se agregó una regresión de cobertura de las 24 referencias. Las cantidades de campaña proceden del catálogo inicial, no de la base de Oracle.
- Paquete de actualización validado y sin bases, claves o secretos. La actualización de Oracle y la publicación de los anuncios siguen siendo acciones del propietario.

Las secciones siguientes conservan las verificaciones anteriores, hasta el 16 de septiembre de 2026.

## Bandeja de solicitudes

- **65 pruebas aprobadas**. Cuatro regresiones nuevas cubren los filtros por estado, apertura explícita del detalle, navegación anterior/siguiente, búsqueda sin tildes, paginación y conservación del contexto al regresar.
- Las solicitudes nuevas se muestran directamente en una bandeja, sin combo de selección. Tabla en escritorio y tarjetas en pantallas estrechas, con etiquetas de estado y contadores.
- Chrome a 1440, 768, 390 y 320 píxeles: sin desbordamientos; apertura desde cada fila/tarjeta; anterior/siguiente; segunda página; cambio de estados y regreso con búsqueda y página conservadas.
- Se mantienen verificadas las contingencias de stock, ajustes, alternativas, cancelación y conversión a venta con ticket. Cambiar el estado conserva el detalle abierto; al volver, la solicitud aparece en su estado correspondiente.
- Pruebas con solicitudes ficticias en SQLite temporal. No se escribieron datos en la tienda publicada.

## Auditoría general de calidad

- **61 pruebas automatizadas aprobadas**, incluidas doce regresiones nuevas en `tests/test_quality.py` y una de tildes/eñe en `tests/test_ticket.py`.
- Chrome local a 320, 390, 768 y 1440 píxeles: catálogo/pedido, navegación, avisos, carrito, formularios, zoom suave y movimiento reducido.
- Alta con fotos inválidas/exceso de archivos, recuperación sin perder campos, pedido sin teléfono con destino WhatsApp interceptado, venta con confirmación y ticket PNG.
- `pip check` sin incompatibilidades. Pruebas con datos temporales, sin escrituras en producción.
- Lista completa de cambios, evidencia y límites en [AUDITORIA_CALIDAD.md](AUDITORIA_CALIDAD.md). Las secciones siguientes conservan el historial de verificaciones anteriores.

## Barra pública y actualización de vistas

- 48 pruebas aprobadas. Regresiones nuevas: recarga de una función antigua sin `nav_key` y mensaje explícito ante una versión de vistas incompatible.
- La navegación pública usa ancho completo y se desplaza con el contenido, sin quedarse encima de las tarjetas.
- Chrome a 1440 y 390 píxeles: comprobación de posición al hacer scroll y apertura de «Mi pedido» sin excepciones.
- Para actualizar, reemplazar juntos `app.py`, `order_views.py`, `inventory.py` y `styles.css`, y reiniciar Streamlit. El ZIP de publicación contiene el conjunto completo y excluye secretos y bases locales.

## Catálogo independiente y pedido sin teléfono

- 46 pruebas automatizadas: el pedido público no solicita teléfono ni exige nombre, conserva el stock y prepara el enlace al número del negocio. Se mantiene la revisión privada y las contingencias.
- La caché valida que existan los métodos de solicitudes; una conexión obsoleta se reconstruye sin reiniciar existencias. La revisión del módulo cargado también se contrasta con el archivo para detectar actualizaciones en caliente. Un despliegue incompleto muestra qué archivos actualizar en lugar de fallar al pulsar el botón.
- Chrome móvil: vista pública sin navegación administrativa, registro sin teléfono, apertura automática del destino WhatsApp interceptada para no navegar al servicio real, y comprobación de la solicitud desde `?vista=admin`.
- Si el navegador bloquea pestañas nuevas, el enlace «Continuar en WhatsApp» permanece disponible. El usuario todavía debe enviar el mensaje en WhatsApp.

## Pedidos públicos y solicitudes privadas

- 45 pruebas aprobadas en SQLite temporal: registro sin modificar stock, reintentos sin duplicar solicitudes, enlace WhatsApp al destino correcto, agotados, cambios de precio, ajustes, alternativas, cancelación y conversión a venta con ticket.
- Dos conversiones simultáneas de la misma solicitud producen una sola venta. La falta de stock revierte también el cambio de estado de la solicitud. Se conserva el pedido original.
- Respaldo versión 3 incluye solicitudes y admite restaurar versiones 1 y 2. Límites por sesión y validación de contacto cubiertos.
- Chrome a 390 px: carrito público, formulario, enlace de WhatsApp inspeccionado sin enviar mensajes, bandeja privada y confirmación de venta con descarga PNG.
- No se realizaron pruebas de escritura en la base publicada ni en PostgreSQL. Los cambios requieren subir los archivos y reiniciar Streamlit.

## Bordes y encuadre de fotos

- 36 pruebas aprobadas. Nuevas comprobaciones del guardado y reapertura del encuadre, límites de zoom, conservación de existencias y restauración del encuadre desde respaldo.
- Chrome local a 1440 y 390 píxeles: formularios con bordes, campos de texto, cantidades, selector de pago y notas. Editor con vista previa; zoom guardado al 150 % y ampliación al pasar el mouse en carrito al 247,5 %.
- La preferencia por producto se guarda en `settings` dentro de la misma transacción de edición; no requiere cambiar las tablas existentes. Las imágenes originales se conservan.
- La lectura de la URL publicada no estuvo disponible; la comprobación se realizó sobre el proyecto local con una base temporal.

## Actualización del recurso de base de datos

- 34 pruebas aprobadas. La caché de conexión ahora incluye la huella de `inventory.py`, para reconstruir el recurso al actualizar su implementación.
- Prueba de regresión: actualización desde una base sin tabla de fotos, creación de la tabla nueva y conservación de existencias previamente ajustadas.
- Al publicar, subir juntos `app.py` e `inventory.py`. Si el servidor conserva una versión anterior del módulo, reiniciar la app desde Streamlit.

## Inventario visual y fotos reales

- 33 pruebas automatizadas aprobadas. Cobertura nueva: persistencia de varias fotos, sustitución y eliminación, validación de imágenes, guardado atómico ante errores y versiones desactualizadas, respaldo/restauración y compatibilidad con respaldos anteriores.
- Chrome con base temporal: acceso desde tarjeta a edición, subida múltiple con vista previa, guardado, carrete en carrito, zoom al pasar el mouse y ancho del carrete a 1440 y 390 píxeles.
- La tabla adicional `product_photos` se crea al iniciar la app; no altera las existencias. Los nuevos respaldos usan versión 2; se siguen admitiendo respaldos de versión 1.

## Carrito visual y ticket para el cliente

- 30 pruebas automatizadas: confirmación, descarga disponible, PNG válido, nombres largos y omisión de notas y datos privados en el ticket.
- Chrome: fotos y tarjetas dentro de pantalla a 1440 y 390 píxeles; venta en SQLite temporal y descarga automática de un archivo PNG confirmadas.
- El ticket se genera desde los importes históricos de la venta y se puede descargar nuevamente en Ventas. Las ventas anuladas generan una imagen marcada como anulada.
- La descarga automática depende de las políticas del navegador; queda un botón de descarga manual. No se realizaron ventas en la app publicada.

## Corrección de iconos y vistas

- **29 pruebas automatizadas aprobadas** con Python 3.12, Streamlit 1.63.0 y SQLAlchemy 2.0.52 (`.venv/Scripts/python -m pytest tests -q`).
- Chrome sin ventana: catálogo a 1440, 768 y 390 píxeles; fuentes nativas de iconos conservadas, 12 tarjetas dentro del ancho visible sin superponerse y apertura de «Ver detalles» correcta. En móvil las tarjetas aprovechan el ancho disponible.
- Nuevas pruebas: reinicio de paginación al ordenar, búsqueda sin resultados, limpieza de filtros y búsqueda sin tildes.
- Se mantienen las pruebas de acceso, ventas, cantidades, anulaciones, ajustes, edición concurrente y respaldo.
- La primera ejecución excedió el tiempo de arranque de una prueba; la segunda ejecución completa terminó con 29 aprobadas en 11,96 segundos.
- Se utilizaron bases SQLite temporales. No se probaron escrituras contra PostgreSQL ni contra la app publicada; estos cambios quedan pendientes de subir a GitHub.

## Verificación anterior (13 de septiembre)

**27 pruebas automatizadas aprobadas**, con Python 3.14, Streamlit 1.63.0 y SQLAlchemy 2.0.49. El servidor local devuelve HTTP 200 y su comprobación de salud responde `ok`.

Las pruebas usan bases SQLite temporales. La base entregada conserva **24 referencias, 360 unidades y cero ventas**.

## Cobertura

- Conciliación de todas las referencias, fotografías, cantidades y valor con el catálogo inicial.
- Conservación de compatibilidades, incluidos A16/A17/A26 y los nombres iPhone del PDF.
- Venta con precio histórico, descuento exacto y movimiento con saldo.
- Reinicio e importación repetida sin reponer artificialmente el inventario.
- Doble solicitud y solicitudes simultáneas de la misma venta sin duplicación.
- Dos ventas concurrentes que compiten por el stock: solo se acepta la que tiene unidades.
- Carrito de varios artículos: reversión completa si uno no tiene disponibilidad.
- Rechazo de cantidades negativas, cero, decimales y tipos inválidos.
- Rechazo de precios desactualizados y artículos archivados.
- Anulaciones repetidas y concurrentes sin reponer dos veces.
- Ajustes justificados, repetidos sin duplicación y sin existencias negativas.
- Edición que detecta cambios de otra sesión.
- Creación de artículos de otra categoría y persistencia de fotos subidas.
- Respaldo y restauración en base vacía, con imágenes y ventas conservadas.
- Hash de contraseña y rechazo del acceso incorrecto.
- Modo de producción bloqueado cuando falta acceso o se intenta usar SQLite temporal.
- Formularios reales de Streamlit: búsqueda pública, acceso, carrito, confirmación, alta, reposición, anulación, navegación y salida.

## Pendiente al publicar

No hubo navegador conectado disponible en este entorno. Por ello, **la revisión visual en un celular real sigue pendiente**; no se afirma que se haya hecho. La app incluye estilos adaptables y las pantallas fueron verificadas mediante Streamlit AppTest.

También faltan la conexión real a Neon y la prueba de despliegue en Streamlit con tus cuentas. La guía incluye un recorrido de venta y anulación para verificar el inventario desde dos dispositivos y después de reiniciar la nube.

## Repetir pruebas

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
```

El PDF se revisó visualmente y se extrajo por la posición de cada tarjeta. Se usó el último nombre dibujado en cada tarjeta para respetar las compatibilidades que fueron añadidas sobre los títulos anteriores. Los precios se extrajeron como centavos enteros, sin estimarlos por la foto.
